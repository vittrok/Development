\pset format csv
\pset footer off
\o 'D:/Documents/LocalGithubRepos/Development/matches/netlify-prod/dev/fixtures/db_schema_2025-09-10.constraints.csv'
SELECT
  tc.constraint_schema,
  tc.table_name,
  tc.constraint_name,
  tc.constraint_type
FROM information_schema.table_constraints tc
WHERE tc.constraint_schema='public'
ORDER BY tc.table_name, tc.constraint_name;
\o
\q
