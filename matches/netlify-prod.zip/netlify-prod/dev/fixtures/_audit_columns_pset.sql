\pset format csv
\pset footer off
\o 'D:/Documents/LocalGithubRepos/Development/matches/netlify-prod/dev/fixtures/db_schema_2025-09-10.columns.csv'
SELECT
  c.table_schema,
  c.table_name,
  c.ordinal_position,
  c.column_name,
  c.data_type,
  c.is_nullable,
  c.column_default
FROM information_schema.columns c
WHERE c.table_schema='public'
ORDER BY c.table_name, c.ordinal_position;
\o
\q
