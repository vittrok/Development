﻿This folder stores local request/response fixtures (curl payloads, temp SQL).
Files here are ignored by Git to avoid leaking test data or noise.
