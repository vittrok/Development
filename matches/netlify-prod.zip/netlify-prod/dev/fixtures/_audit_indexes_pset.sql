\pset format csv
\pset footer off
\o 'D:/Documents/LocalGithubRepos/Development/matches/netlify-prod/dev/fixtures/db_schema_2025-09-10.indexes.csv'
SELECT
  schemaname AS schema_name,
  tablename  AS table_name,
  indexname  AS index_name,
  indexdef   AS index_def
FROM pg_indexes
WHERE schemaname='public'
ORDER BY tablename, indexname;
\o
\q
