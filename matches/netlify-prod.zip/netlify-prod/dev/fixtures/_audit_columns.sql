\copy (
  SELECT
    c.table_schema,
    c.table_name,
    c.ordinal_position,
    c.column_name,
    c.data_type,
    c.is_nullable,
    c.column_default
  FROM information_schema.columns c
  WHERE c.table_schema='public'
  ORDER BY c.table_name, c.ordinal_position
) TO STDOUT WITH CSV HEADER;
