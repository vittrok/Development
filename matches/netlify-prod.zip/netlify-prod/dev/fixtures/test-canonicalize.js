// matches/netlify-prod/dev/fixtures/test-canonicalize.js
const assert = require('assert');
const path = require('path');

// виконання від кореня matches/netlify-prod
process.chdir(path.join(__dirname, '..', '..'));

const {
  canonicalizeTeam,
  canonicalizePair,
  _normKey,
  _loadAliasMap
} = require(path.join(process.cwd(), 'functions', '_util', 'canonicalize.js'));

// sanity: мапа завантажується
const map = _loadAliasMap();
assert(map instanceof Map && map.size > 0, 'alias map must be a Map with entries');

// нормалізація ключа
assert.strictEqual(_normKey('  Man   Utd  '), 'man utd');

// кейси з існуючого JSON (різні регістри/пробіли):
assert.strictEqual(canonicalizeTeam('Man Utd'), 'Manchester United');
assert.strictEqual(canonicalizeTeam('  MAN   CITY '), 'Manchester City');
assert.strictEqual(canonicalizeTeam('Spurs'), 'Tottenham Hotspur');
assert.strictEqual(canonicalizeTeam('Barça'), 'FC Barcelona');
assert.strictEqual(canonicalizeTeam('Bayern Munich'), 'Bayern München');
assert.strictEqual(canonicalizeTeam('Shakhtar'), 'Shakhtar Donetsk');
assert.strictEqual(canonicalizeTeam('Dynamo Kyiv'), 'Dynamo Kyiv'); // вже канон
assert.strictEqual(canonicalizeTeam('Ukraine U-19'), 'Ukraine U19');

// passthrough (немає ключа):
assert.strictEqual(canonicalizeTeam('Some New Team'), 'Some New Team');

// пара і незалежність від порядку
const p1 = canonicalizePair('Spurs', 'Man Utd');
const p2 = canonicalizePair('man utd', '  spurs ');
assert.strictEqual(p1.pairKey, 'Manchester United|Tottenham Hotspur');
assert.strictEqual(p2.pairKey, p1.pairKey);

console.log('ALL OK');
