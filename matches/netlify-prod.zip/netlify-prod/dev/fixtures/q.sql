-- File: matches/netlify-prod/dev/fixtures/q.sql
-- Purpose: export DB metadata snapshots to CSV in dev/fixtures
-- NOTE: шляхи вкажемо з PowerShell через \copy ... TO '<abs path>' CSV HEADER

-- 1) COLUMNS VIEW
WITH cols AS (
  SELECT
    current_database()                           AS db,
    c.table_schema,
    c.table_name,
    c.ordinal_position,
    c.column_name,
    c.data_type,
    c.is_nullable,
    c.column_default
  FROM information_schema.columns c
  WHERE c.table_schema NOT IN ('pg_catalog','information_schema')
)
SELECT * FROM cols
ORDER BY table_schema, table_name, ordinal_position;

-- 2) CONSTRAINTS VIEW
WITH cons AS (
  SELECT
    current_database()                AS db,
    n.nspname                         AS table_schema,
    rel.relname                       AS table_name,
    con.conname                       AS constraint_name,
    con.contype                       AS constraint_type,   -- p=PK, u=UK, f=FK, c=CHECK, x=EXCL
    pg_get_constraintdef(con.oid)     AS definition
  FROM pg_constraint con
  JOIN pg_class rel      ON rel.oid = con.conrelid
  JOIN pg_namespace n    ON n.oid   = rel.relnamespace
  WHERE n.nspname NOT IN ('pg_catalog','information_schema')
)
SELECT * FROM cons
ORDER BY table_schema, table_name, constraint_name;

-- 3) INDEXES VIEW
WITH idx AS (
  SELECT
    current_database()                AS db,
    n.nspname                         AS table_schema,
    t.relname                         AS table_name,
    i.relname                         AS index_name,
    ix.indisprimary                   AS is_primary,
    ix.indisunique                    AS is_unique,
    pg_get_indexdef(i.oid)            AS indexdef
  FROM pg_index ix
  JOIN pg_class i     ON i.oid = ix.indexrelid
  JOIN pg_class t     ON t.oid = ix.indrelid
  JOIN pg_namespace n ON n.oid = t.relnamespace
  WHERE n.nspname NOT IN ('pg_catalog','information_schema')
)
SELECT * FROM idx
ORDER BY table_schema, table_name, index_name;
