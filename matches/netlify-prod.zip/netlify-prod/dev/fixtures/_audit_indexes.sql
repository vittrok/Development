\copy (
  SELECT
    schemaname AS schema_name,
    tablename AS table_name,
    indexname AS index_name,
    indexdef  AS index_def
  FROM pg_indexes
  WHERE schemaname='public'
  ORDER BY tablename, indexname
) TO STDOUT WITH CSV HEADER;
