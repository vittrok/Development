// dev/fixtures/test-confidence.js
const path = require('path');
process.chdir(path.join(__dirname, '..', '..')); // -> matches/netlify-prod

const { computeHomeAwayConfidence } = require(path.join(process.cwd(), 'functions', '_util', 'confidence.js'));
const tests = require(path.join(process.cwd(), 'dev', 'fixtures', 'confidence-test.json'));

let failed = 0;
for (const t of tests) {
  const { level, score, reasons } = computeHomeAwayConfidence(t.row);
  const ok = level === t.expect;
  if (!ok) {
    console.error(`FAIL: ${t.name} ⇒ got level=${level} (score=${score}, reasons=${reasons.join('+')}), expected=${t.expect}`);
    failed++;
  } else {
    console.log(`OK  : ${t.name} ⇒ ${level} (score=${score}, reasons=${reasons.join('+')})`);
  }
}

if (failed) {
  console.error(`\nFAILED: ${failed} case(s)`);
  process.exit(1);
} else {
  console.log(`\nALL OK`);
}
